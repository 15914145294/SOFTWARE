""" 
@author: lileilei
@file: config_dingding.py 
@time: 2018/4/12 14:17 
"""
Dingtalk_access_token=""